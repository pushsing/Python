def print_facotrs(x):
    ls=list()
    for i in range(1,x+1):
        if x % i == 0:
           print(i, end= ' ')
        else:
            continue



a = int(input())
print_facotrs(a)
