def Fib(n):
    if(n==1):
        return 0
    elif (n == 2):
        return 1
    else:
        return Fib(n-2)+Fib(n-1)

n = int(input())
for i in range(1,n+1):
    print (Fib(i), end=' ')
