def charcheck(char):
    v='aeiou'
    V='AEIOU'
    if char in v:
        print(True)
    if char in V:
        print(True)
    else:
        print(False)

char =input()
charcheck(char)