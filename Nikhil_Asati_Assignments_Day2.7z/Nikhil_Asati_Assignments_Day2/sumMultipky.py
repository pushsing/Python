def Sum(ls):
    sum=0
    l=0
    for i in ls:
        print(i)
        sum = sum + ls[l]
        l=l+1
    return print(sum)

def Mul(ls):
    mul =1
    l=0
    for i in ls:
        print(i) # picking values of list that's why pick l to act as a counter
        mul = mul * ls[l]
        l+=1
    return print(mul)

ls=[1,3,5]
Sum(ls)
Mul(ls)
