def max_of_three(a, b, c):
    if a > b and a > c:
        return print(a , "is greater")
    if c > a and c > b:
        return print(c , "is greater")
    if b > a and b > c:
        return print(b , "is greater")

a = int(input())
b = int(input())
c = int(input())
max_of_three(a, b, c)