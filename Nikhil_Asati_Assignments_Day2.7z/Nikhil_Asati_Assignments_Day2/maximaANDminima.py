def max(a,b):
    if(a>b):
        return (print("Hurray! a is greater"))
    elif(b>a):
        return (print("Sad b is greater"))
    else:
        return(print ("I believe in equality"))

a = int(input())
b = int(input())

max(a,b)