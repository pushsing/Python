def lenstr(str):
    count=0
    for i in str:
        count+=1
    return( print (count))

str = input()
lenstr(str)