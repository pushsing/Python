#Fibonacci Sequence:

def fib(n):
    series=[0,1]
    if n==1:
        return print(series[0])
    elif n==2:
        return print(series[1])
    elif n > 2:
        for i in range(n-1):
            series.append(series[i]+series[i+1])
    print(series[0:n])


n=int(input())
fib(n)
