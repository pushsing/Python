def revString(str1):
    strRev = str()
    n = len(str1)
  #  print(n)
    for i in range(n):
        strRev =strRev + str1[n-i-1]
    print (strRev)


str1 = 'I work for Capgemini India'
revString(str1)