#To print the sum of two numbers

def Toadd(a, b):
    return a+b

print (Toadd(5,3))