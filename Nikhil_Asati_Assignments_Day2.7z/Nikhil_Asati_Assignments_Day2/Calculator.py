#3.	Write a Python based program which acts as a calculator .(Function based)
def cal(n,a,b):
    if(n==1):
        ans=a+b
    elif(n==2):
        ans=abs(a-b)
    elif(n==3):
        ans=(a*b)
    elif(n==4):
        ans=float(a/b)
    print("Your answer is", ans)


print("Welcome!")
print ("Choose the options: 1 - Add, 2- Sub,3- Mul, 4-Div")
n=int(input())
a=int(input())
b=int(input())
cal(n,a,b)
