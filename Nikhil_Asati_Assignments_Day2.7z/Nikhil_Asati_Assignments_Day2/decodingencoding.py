def decode(str):
    strnew = ""
    v='aeiouAEIOU'
    for i in range(len(str)):
        if str[i] in v:
            strnew = strnew+str[i]
        else:
            strnew = strnew + str[i] + 'o' +  str[i]
    print (strnew)

str =input()
decode(str)
