Details = {'Name': 'Rama', 'City': 'Chennai', 'Age': 23}
print ("dict['Name']: ", Details['Name'])
print ("dict['City']: ", Details['Age'])
print ("dict['Age']: ", Details['Name'])
Details['State']= 'TamilNadu'
print(Details)
print(len(Details))


details = {'Name': 'Raghu', 'City': 'ABC'}
print(details)
details['Name'] = 'Sagar'
print(details)
del details['Name']
print(details)