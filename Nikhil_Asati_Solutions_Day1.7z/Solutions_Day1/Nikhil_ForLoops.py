tup1 = (10.0, 2, False, "String");
print(tup1[0:4])
print(tup1[1])
print(tup1[0])
#print(tup1[0:3]);  # Conventional method

sliceObj1 = slice(0, 3)
print (tup1 [sliceObj1])

#print(tup1[1:4]);  # Conventional Method
sliceObj2 = slice(1, 4)
print (tup1 [sliceObj2])

#print(tup1[2:4]);  # Conventional Method
sliceObj3 = slice(2, 4)
print(tup1[sliceObj3])

#For Loop
tup2 = ("Bohr", "Leibniz", "Einstein")
list1 =[]
list2 =  [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
for i in range(0,3):
    print (tup2[i])

for j in range(2,8):
    list1.append(list2[j]);

print ("Updated List : ", list1)