list1 = ["a", "b", "c", "d"]
list2 = [1, 2, 3, 4, 5 ]
list3 = [1, 2, 3, False, "String"]

print (list1)
print (list2[1])
print (list3[3])

list4 = [1,2,3]
list4[0]=2
list4[1]=3
list4[2]=4
list4.append(6)
print(list4)

list5 = [1, 2, 3, 4, 5, 6, 7]
print(list5[0:4])
print(list5[2:5])
print(list5[1:7])

list6= ["Bob Dylan", "Like a", "Rolling Stone"]
print(list6.index("Rolling Stone"))
print(list6.insert(0, "1965"))
print(list6)

list7 = ["McCartney", "Lennon", "Starr", "Harrison", "Sutcliffe"]
list7.remove("Sutcliffe")
#print(list7)
print(list7.pop(1))
#print(list7)
print(list7.pop(2))
#print(list7)