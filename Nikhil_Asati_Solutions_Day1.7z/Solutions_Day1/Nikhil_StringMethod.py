str1 = 'Python'
strlen = len(str1)
# print(strlen)

strYTHlen = len(str1[1:4])
num1 = 1.32
print(num1)
num2 = str(num1)
print(num2[-1])  # typecasted from float to string

# num2=(num1[-1])

state = "tamil nadu"
city = "CHENNAI"
name = name.upper()
city = city.lower()

print(name)
print(city)
